/*
 * A test program for GeekOS user mode
 */

#include <conio.h>

int main(int argc, char** argv)
{
    Print_String("Hello World!\n");
    return 0;
}
